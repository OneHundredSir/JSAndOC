//
//  main.m
//  JS_OC
//
//  Created by Harvey on 15/11/7.
//  Copyright © 2015年 Halley. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
